package com.example.todoapp.model;

import java.time.LocalDate;

import jakarta.persistence.*;


@Entity
@Table(name = "todos")
public class Todo {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String description;
    private boolean completed;
    private LocalDate dueDate;
    private String title;
    
    //default constructor
    public Todo(){}

    public Todo(String title, String description, boolean completed, LocalDate dueDate){
        this.title = title;
        this.description = description;
        this.completed = completed;
        this.dueDate = dueDate;
    }

//getter and setters((you can use Lombok if you prefer))
    public Long getid(){
        return id;
    }
    public void setid(Long id){
        this.id = id;
    }
    public String getTitle() {
            return title;
    }

    public void setTitle(String title) {
            this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
     public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

}
